def show(fun):
    print(fun(10))
    print("123")


show(lambda i: i + 5)
