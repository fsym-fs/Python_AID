update class_1 set age = 19 where name = 'Tome';
update class_1 set age = age-2 where age = 19;
delete from class_1 where name = 'Tome';

insert into marathon values(1,'曹操','1990-2-5','2020/1/5 12:12:12','2:10:13');


insert into marathon values(2,'孙权','1993-2-5','2020/1/5 12:19:12','2:10:13');
insert into marathon values(3,'刘备','1988-2-5','2020/1/5 12:14:12','3:10:13');
insert into marathon values(4,'夏侯惇','1989-2-5','2020/1/5 12:22:12','4:10:13');
insert into marathon values(5,'魏延','1995-2-5','2020/1/5 12:32:12','3:09:13');
insert into marathon values(6,'程普','1993-2-5','2020/1/5 16:12:12','4:10:03');