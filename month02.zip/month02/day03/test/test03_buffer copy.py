# f = open("day03/test/1.txt","wb",1)
# f.write(b"aaaaaaaaaaadf")
# f.write(b"wwwwwwwwwwwww")
# f.close