#!/usr/bin/python3

a = 1

print(a)

b = input(">>")

print(b)
print("hello world")
print("hello world")