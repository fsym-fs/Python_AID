#!/usr/bin/python3

"""
声明在执行过程中该程序解释器的位置
"""

print("Hello world!")