"""
1-100的乘积 
"""

sum = 1
 

for i in range(1,101):
    sum *= i 

print(sum)
