# 进行具体的数据处理

import time

def get_time():
    return time.ctime()

def hello():
    return "Hello world"

def bye():
    return "Good bye"