"""
进程退出
"""

import os,sys

# os._exit(0)  # 进程退出

sys.exit("Process exit") # 进程退出

print("进程退出")