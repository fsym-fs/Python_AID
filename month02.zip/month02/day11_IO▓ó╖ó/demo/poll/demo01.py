a = {"a":1,"b":2}
print(a["a"])