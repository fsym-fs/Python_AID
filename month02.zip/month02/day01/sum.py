print("123")
"""
    1-100加和
"""
Sum = 1
for i in range(1,101):
    Sum *= i
print(Sum)
