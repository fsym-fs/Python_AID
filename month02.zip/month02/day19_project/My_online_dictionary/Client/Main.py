from Client.View import Client_View

if __name__ == '__main__':
    client = Client_View()
    client.show()
