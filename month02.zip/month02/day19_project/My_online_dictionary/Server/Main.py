from Server.View import Server_View

if __name__ == '__main__':
    server = Server_View()
    server.show()
