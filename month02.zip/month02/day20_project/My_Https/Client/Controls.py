from socket import *


class Client_Controls:
    pass
