from Client.Controls import Client_Controls


class Client_View:
    pass