import pymysql


class Server_Models:
    pass