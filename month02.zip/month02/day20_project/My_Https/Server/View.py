from Server.Controls import Server_Controls


class Server_View:
    pass
