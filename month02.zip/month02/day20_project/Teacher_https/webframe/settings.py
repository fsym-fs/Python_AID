"""
webframe部分的配置文件
"""

# address
frame_ip = '0.0.0.0'
frame_port = 8011

DEBUG = True

# 网页位置
dir_name = "./static"
