"""
配置文件
"""

# [HTTP SERVER address]
HOST = '0.0.0.0'
PORT = 8000

# [DEBUG]
DEBUG = True

# 访问webframe需要的地址
frame_ip = '127.0.0.1'
frame_port = 8011