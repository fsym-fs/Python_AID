import pymysql
db = pymysql.connect\
    (
        
    )
con = db.cursor()
