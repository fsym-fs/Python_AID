# ubuntu 18.04 LTS 2019.11
# http://tedu.cn

print("hello world!")
